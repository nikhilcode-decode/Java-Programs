package NewKeywords;
import java.util.*;
public class FrequencyofCharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter String");
		String s= sc.next();
		
		System.out.println("Enter a charcter to find frequency : ");
		char ch = sc.next().charAt(0);
		
		int frequency = 0;
		
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)== ch)
			{
				frequency++;
			}
		}
		
		System.out.println("The frequency of character in the given string is: " + frequency);
	}

}
