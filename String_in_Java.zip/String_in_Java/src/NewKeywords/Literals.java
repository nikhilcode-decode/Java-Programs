package NewKeywords;

public class Literals {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello");
		String Name = new String("Nikhil");
		System.out.println(Name);
		
		String name="Nikhil";
		name=name.concat(" Pradhan");
		System.out.println(name);
		

	}

}
