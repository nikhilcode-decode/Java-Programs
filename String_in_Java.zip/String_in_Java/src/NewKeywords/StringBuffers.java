package NewKeywords;

public class StringBuffers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer sb= new StringBuffer("Nikhil");
		//sb.append("Hello");
		//sb.append("World");
		//sb.insert(1,"hello");
		//sb.reverse();
		//String str=sb.toString();
		int p=sb.capacity();
		int q=sb.length();
		System.out.println(p);
		System.out.println(q);
		System.out.println(sb);
		
		
	}

}
