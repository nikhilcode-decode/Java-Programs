package NewKeywords;
import java.util.*;
import java.util.Scanner;

import java.util.Scanner;

public class StringMethods {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s;
        
        System.out.println("Enter String : ");
        s=sc.next();

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. String length");
            System.out.println("2. Character at a specific position");
            System.out.println("3. Substring from a specific position");
            System.out.println("4. Concatenate strings");
            System.out.println("5. Index of a substring");
            System.out.println("6. Check Equality");
            System.out.println("7. Compare ASCII values");
            System.out.println("8. Convert to lowercase");
            System.out.println("9. Convert to uppercase");
            System.out.println("10. Trim the word");
            System.out.println("11. Replace characters");
            System.out.println("12. Exit");

            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("String length = " + s.length());
                    break;
                case 2:
                    System.out.print("Enter position: ");
                    int pos = sc.nextInt();
                    System.out.println("Character at position " + pos + " = " + s.charAt(pos));
                    break;
                case 3:
                    System.out.print("Enter starting position: ");
                    int start = sc.nextInt();
                    System.out.println("Substring from position " + start + " = " + s.substring(start));
                    break;
                case 4:
                    System.out.print("Enter string to concatenate: ");
                    String concatStr = sc.next();
                    System.out.println("Concatenated string = " + s.concat(concatStr));
                    break;
                case 5:
                    System.out.print("Enter substring to find: ");
                    String substring = sc.next();
                    System.out.println("Index of " + substring + " = " + s.indexOf(substring));
                    break;
                case 6:
                    System.out.print("Enter another string for equality check: ");
                    String checkStr = sc.next();
                    System.out.println("Checking Equality = " + s.equals(checkStr));
                    break;
                case 7:
                    System.out.print("Enter another string for ASCII comparison: ");
                    String compareStr = sc.next();
                    int asciiDiff = s.compareTo(compareStr);
                    System.out.println("The difference between ASCII values is = " + asciiDiff);
                    break;
                case 8:
                    System.out.println("Changing to lowercase = " + s.toLowerCase());
                    break;
                case 9:
                    System.out.println("Changing to uppercase = " + s.toUpperCase());
                    break;
                case 10:
                    System.out.println("Trim the word = " + s.trim());
                    break;
                case 11:
                    System.out.print("Enter character to replace: ");
                    char oldChar = sc.next().charAt(0);
                    System.out.print("Enter character to replace with: ");
                    char newChar = sc.next().charAt(0);
                    System.out.println("Replaced " + oldChar + " with " + newChar + " -> " + s.replace(oldChar, newChar));
                    break;
                case 12:
                    System.out.println("Exiting the program. Goodbye!");
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }
}
