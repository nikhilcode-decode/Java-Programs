package NewKeywords;
import java.util.*;
public class SwapString {
	
	public static char[] swap(String s,int i, int j)
	{
		char ch[]=s.toCharArray();
		char temp=ch[i];
		ch[i]=ch[j];
		ch[j]=temp;
		return ch;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		 System.out.println("Enter String : ");
	        String s = sc.next();

	        System.out.println("Enter the indices to swap (space-separated): ");
	        int i = sc.nextInt();
	        int j = sc.nextInt();

	        char[] result = swap(s, i, j);

	        System.out.println("After swapping: " + new String(result));

		

	}

}
