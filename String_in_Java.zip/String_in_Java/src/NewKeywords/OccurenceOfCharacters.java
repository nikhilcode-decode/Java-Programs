package NewKeywords;
import java.util.*;
public class OccurenceOfCharacters {
	
	public static void GetOccurence(String str)
	{
		int count[]=new int[256];
		int len = str.length();
		for(int i=0;i<len;i++)
		{
			count[str.charAt(i)]++;
		}
		for(int i=0;i<count.length;i++)
		{
			if(count[i]>0)
			{
				System.out.println((char)i+" "+count[i]+" "+"times");
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String : ");
		String str=sc.next();
		
		GetOccurence(str);

	}

}
