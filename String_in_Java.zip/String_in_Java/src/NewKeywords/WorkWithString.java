package NewKeywords;

public class WorkWithString {

	static public void main(String[] Nikhil) {
		// TODO Auto-generated method stub
		
		System.out.println("Hello Nikhil");

	}

}
